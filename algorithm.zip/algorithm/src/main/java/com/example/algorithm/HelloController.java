package com.example.algorithm;

import java.io.IOException;
import java.net.URL;
import java.util.*;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

public class HelloController {

    @FXML
    private ResourceBundle resources;

    @FXML
    private URL location;

    @FXML
    private TextField Location_A;
    @FXML
    private Button change_information;

    @FXML
    private TextField Location_B;
    @FXML
    private Button all_bus;
    @FXML
    private Button all_bus_information;
    @FXML
    private TextArea information_Field;

    @FXML
    private Button main_button;

    HashMap<String, ArrayList<String>> information = new HashMap<>();
    HashMap<String, Integer> sortmap = new HashMap<>();
    HashMap<String, Integer> information_obout_rout = new HashMap<>();

    @FXML
    void initialize() {

        ArrayList<String> arr = new ArrayList<>(Arrays.asList(
                "ТЦ Asia Park", "Микрорайон Аксай-1 (ул. Толе би)", "Момышулы (ул. Толе би)",
                "Момышулы (проспект Райымбека)", "Яссауи (проспект Райымбека)", "Супермаркет Small",
                "Микрорайон Аккент", "Авторынок Жибек Жолы", "Авторынок Жибек Жолы-2",
                "Городская больница №7", "Микрорайон Теректы", "ТРК Молл Апорт", "Рынок Алтын Орда",
                "Микрорайон Асыл Арман", "Поворот на пос. Райымбек", "Поворот на с. Райымбек", "КИЗ",
                "Магазин (ул. Гагарина)", "Кумтоган", "Кумтоган",
                "Бахар", "Долан", "Алмалыбак с", "СДУ", "ЖК Алтын ауыл", "Болашак", "Достык",
                "Автостанция", "10 лет Независимости", "Аубая Байгазиева", "ТЦ Алатау", "Макашева",
                "Автопарк", "Саукеле", "Жазира", "Айтей батыра"
        ));
        information.put("230", arr);
        ArrayList<String> arr1 = new ArrayList<>(Arrays.asList(
                "Метро Бауыржана Момышулы", "Яссауи (прооспект Абая)", "Косынова",
                "Аспандиярова (проспект Абая)", "НИШ (Микрорайон Калкаман)", "По требованию (ул. Береке)",
                "ЦОН (Микрорайон Шугыла)", "ЖК Шугыла-City", "ЖК Шугыла", "Сабденова(ул. Алатау)",
                "КГ Елисейские поля", "ЖК Алма Сити", "Жакыбаева (Проспект Алатау)", "Дала",
                "Ташкентский тракт", "ТРК Молл Апорт", "ТРК Молл Апорт", "Рынок Алтын Орда",
                "Микрорайон Асыл Арман", "с. Алмалыбак", "Достык", "Шегебаева", "Сатпаева",
                "Ардагерлер", "с. Жалпаксай"
        ));
        information.put("78", arr1);

        ArrayList<String> arr2 = new ArrayList<>(Arrays.asList(
                "Ресторан Куаныш", "Гипермакет Магнум (с. Бесагаш)", "Микрорайон Думан-2",
                "Микрорайон Думан (Талгарский тракт)", "Халык Арена", "Развилка", "Гурилева",
                "Халиулина", "Областная библиотека", "Коперника", "Колпаковского (ул. Жетысуская)",
                "Жангельдина (проспект Райымбека)", "Кунаева (проспект Райымбека)", "Панфилова",
                "Проспект Абылай хана (проспект Райымбека)", "Наурызбай батыра (проспект Райымбека)",
                "Торетай", "КазНИВИ", "Байзакова (проспект Райымбека)", "ТРК Максима",
                "Райымбека (ул. Гончарова)", "Крылова", "Розыбакиева (проспект Райымбека)",
                "Тургут Озала", "Тлендиева", "КазДорНИИ (проспект Райымбека)", "КазАДИ",
                "Утеген батыра (проспект Райымбека)", "Ахрименко", "Оранжерея", "Магазин 12 месяцев",
                "Момышулы (проспект Райымбека)", "Яссауи (проспект Райымбека)", "Супермаркет Small",
                "Микрорайон Аккент", "Авторынок Жибек Жолы-2", "Городская больница №7",
                "Микрорайон Теректы", "ТРК Молл Апорт", "Рынок Алтын Орда", "Микрорайон Асыл Арман"
        ));
        information.put("100", arr2);


        ArrayList<String> arr3 = new ArrayList<>(Arrays.asList(
                "Автовокзал Сайран (ул. Толе Би)", "Утеген батыра (ул. Толе Би)", "Ахрименко",
                "Магазин 12 месяцев", "Момышулы (проспект Райымбека)", "Яссауи (проспект Райымбека)",
                "Супермаркет Small", "Авторынок Жибек Жолы", "Авторынок Жибек Жолы-2",
                "Городская больница №7", "Микрорайон Теректы", "ТРК Молл Апорт", "Рынок Алтын Орда",
                "Микрорайон Асыл Арман", "Поворот на пос. Райымбек", "Поворот на с. Райымбек",
                "Магазин (ул. Гагарина)", "Кумтоган",
                "Долан", "Алмалыбак с. (Карасайский район, Алматинская обл., Казахстан)", "СДУ", "ЖК Алтын ауыл", "Болашак", "Достык",
                "Автостанция", "10 лет Независимости", "Аубая Байгазиева", "ТЦ Алатау", "ЦОН"
        ));
        information.put("459", arr3);
        ArrayList<String> arr4 = new ArrayList<>(Arrays.asList(
                "Автовокзал Сайран (ул. Толе Би)", "ТРК City Plus", "ЖК Эдельвейс", "Казахтелеком",
                "Саина", "Микрорайон Аксай-1 (ул. Толе би)", "Момышулы (ул. Толе би)", "Момышулы (проспект Райымбека)",
                "Яссауи (проспект Райымбека)", "Супермаркет Small", "Микрорайон Аккент", "Авторынок Жибек Жолы",
                "Авторынок Жибек Жолы-2", "Городская больница №7", "Микрорайон Теректы", "ТРК Молл Апорт",
                "Рынок Алтын Орда", "Микрорайон Асыл Арман", "Поворот на пос. Райымбек", "Магазин (ул. Гагарина)",
                "Кумтоган", "Бахар", "Долан", "ул. Майса", "Рынок Барыс 3"
        ));

        information.put("202", arr4);

        ArrayList<String> arr5 = new ArrayList<>(Arrays.asList(
                "Автовокзал Сайран (ул. Толе Би)", "Утеген батыра (ул. Толе Би)", "Ахрименко",
                "Магазин 12 месяцев", "Момышулы (проспект Райымбека)", "Яссауи (проспект Райымбека)",
                "Супермаркет Small", "Авторынок Жибек Жолы", "Авторынок Жибек Жолы-2",
                "Городская больница №7", "Микрорайон Теректы", "ТРК Молл Апорт", "Рынок Алтын Орда",
                "Микрорайон Асыл Арман", "Поворот на пос. Райымбек", "Поворот на с. Райымбек",
                "Магазин (ул. Гагарина)", "Кумтоган", "Кумтоган с. (Карасайский район, Алматинская обл., Казахстан)",
                "Долан", "Алмалыбак с. (Карасайский район, Алматинская обл., Казахстан)", "СДУ", "ЖК Алтын ауыл", "Болашак", "Достык",
                "Автостанция", "10 лет Независимости", "Аубая Байгазиева", "ТЦ Алатау", "ЦОН"
        ));
        information.put("457", arr5);

        main_button.setOnAction(event -> {

            String locationA = Location_A.getText();
            String locationB = Location_B.getText();

            for (Map.Entry<String, ArrayList<String>> entry : information.entrySet()) {
                ArrayList<String> list = entry.getValue();
                if (list.contains(locationA) && list.contains(locationB)) {
                    int a = list.indexOf(locationA);
                    int b = list.indexOf(locationB);
                    information_obout_rout.put(entry.getKey(), Math.abs(a - b) * 3);
                }
            }

            System.out.println(information_obout_rout);

            String key = findMinRout(information_obout_rout);

            information_Field.setText("Number of bus is " + key + " can be in destination about = " + information_obout_rout.get(key) + " minutes");
            sortmap.put(key, information_obout_rout.get(key));
sortmap.clear();

//            String str ="";
//for(Map.Entry<String,Integer>entry : information_obout_rout.entrySet()){
//    str+=("Number of bus is "+ entry.getKey()+ " can be in destination about = "+ entry.getValue()*3+" minutes");
//    str+="\n";
//}
//information_Field.setText(str);

        });

        change_information.setOnAction(actionEvent -> {
            String key = findMinRout(information_obout_rout);
            if (key.equals("")) information_Field.setText("buses don't exist anymore");
            else {
                information_Field.setText("Number of bus is " + key + " can be in destination about = " + information_obout_rout.get(key) + " minutes");
                sortmap.put(key, information_obout_rout.get(key));
                information_obout_rout.remove(key);
            }

        });
        all_bus.setOnAction(actionEvent -> {
           sortmap.remove("");
            System.out.println(sortmap);
            StringBuilder str = new StringBuilder("");
            for (Map.Entry<String, Integer> entry : sortmap.entrySet()) {
                str.append("Number of bus is " + entry.getKey() + " can be in destination about = " + entry.getValue() + " minutes");
                str.append("\n");
            }
            if(!information_obout_rout.isEmpty()) {
                information_obout_rout.remove("");
                for (Map.Entry<String, Integer> entry : information_obout_rout.entrySet()) {
                    str.append("Number of bus is " + entry.getKey() + " can be in destination about = " + entry.getValue() + " minutes");
                    str.append("\n");
                }
            }
            information_Field.setText(str.toString());


        });
        all_bus_information.setOnAction(actionEvent -> {
            Parent root = null;
            try {
                root = FXMLLoader.load(Objects.requireNonNull(getClass().getResource("bus_information.fxml")));
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
            Stage stage = new Stage();
            stage.setScene(new Scene(root));
            stage.show();

        });


    }

    public static String findMinRout(HashMap<String, Integer> map) {
        String key = "";
        int min = Integer.MAX_VALUE;
        for (Map.Entry<String, Integer> entry : map.entrySet()) {
            int val = entry.getValue();
            if (min > val) {
                min = val;
                key = entry.getKey();
            }

        }
        return key;
    }
}

